import NoteDetailPage from '../pages/NoteDetailPage'
export default NoteDetailPage

