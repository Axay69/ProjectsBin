import EditNotePage from '../pages/EditNotePage'
export default EditNotePage

