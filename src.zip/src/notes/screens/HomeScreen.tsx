import Index from '../pages/Index'
export default Index
