import { createMMKV } from 'react-native-mmkv'

export const mmkv = createMMKV({ id: 'offline_field_notes' })
