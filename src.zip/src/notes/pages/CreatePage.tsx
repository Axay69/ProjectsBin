import EditNotePage from './EditNotePage'
export default EditNotePage

